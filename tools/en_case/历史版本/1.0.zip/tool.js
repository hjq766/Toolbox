document.addEventListener('DOMContentLoaded', function() {
    // 初始化 tab 切换
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    // 初始化默认状态 - 第一个 tab 和面板为激活状态
    const defaultTab = tabBtns[0];
    const defaultPane = tabPanes[0];
    defaultTab.classList.add('active');
    defaultPane.classList.add('active');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const target = e.currentTarget;
            const category = target.getAttribute('data-tab');
            
            // 移除所有活动状态
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // 添加新的活动状态
            target.classList.add('active');
            document.getElementById(`${category}-panel`).classList.add('active');
        });
    });
});

// 转换功能
function transform(type) {
    const source = document.getElementById('source').value;
    if (!source) {
        showToast('请输入需要转换的文本！');
        return;
    }

    let result = '';
    switch(type) {
        case 'uppercase':
            result = source.toUpperCase();
            break;
        case 'lowercase':
            result = source.toLowerCase();
            break;
        case 'capitalize':
            result = source.replace(/\b\w/g, char => char.toUpperCase());
            break;
        case 'sentenceCase':
            result = source.toLowerCase().replace(/(^\w|\.\s+\w)/g, char => char.toUpperCase());
            break;
        case 'lineFirstUpper':
            result = source.split('\n').map(line => 
                line.charAt(0).toUpperCase() + line.slice(1)
            ).join('\n');
            break;
        case 'spaceToUnderscore':
            result = source.replace(/\s+/g, '_');
            break;
        case 'underscoreToSpace':
            result = source.replace(/_/g, ' ');
            break;
        case 'underscoreToDash':
            result = source.replace(/_/g, '-');
            break;
        case 'dashToUnderscore':
            result = source.replace(/-/g, '_');
            break;
        case 'underscoreToDot':
            result = source.replace(/_/g, '.');
            break;
        case 'dotToUnderscore':
            result = source.replace(/\./g, '_');
            break;
    }

    document.getElementById('result').value = result;
}

function toggleDropdown() {
    document.getElementById('dropdown-menu').classList.toggle('show');
}

window.onclick = function(event) {
    if (!event.target.matches('.btn')) {
        const dropdowns = document.getElementsByClassName('dropdown-content');
        for (const dropdown of dropdowns) {
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            }
        }
    }
}

function copyResult() {
    const result = document.getElementById('result');
    result.select();
    try {
        document.execCommand('copy');
        showToast('复制成功！');
    } catch (err) {
        console.error('复制错误:', err);
        showToast('复制失败，请手动复制');
    }
}

function cutText() {
    const source = document.getElementById('source');
    source.select();
    try {
        document.execCommand('cut');
        showToast('剪切成功！');
    } catch (err) {
        console.error('剪切错误:', err);
        showToast('剪切失败，请手动剪切');
    }
}

function clearText() {
    document.getElementById('source').value = '';
    document.getElementById('result').value = '';
    showToast('已清空！');
}

// 添加快捷键支持
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey || e.metaKey) {
        switch(e.key.toLowerCase()) {
            case 'u':
                e.preventDefault();
                transform('uppercase');
                break;
            case 'l':
                e.preventDefault();
                transform('lowercase');
                break;
            case 'c':
                if (document.activeElement === document.getElementById('result')) {
                    copyResult();
                }
                break;
        }
    }
}); 