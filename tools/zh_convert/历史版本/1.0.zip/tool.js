// 初始化转换器
const converters = {
    zh_cn: OpenCC.Converter({ from: 'tw', to: 'cn' }),
    zh_hant: OpenCC.Converter({ from: 'cn', to: 'tw' }),
    zh_hk: OpenCC.Converter({ from: 'cn', to: 'hk' }),
    zh_tw: OpenCC.Converter({ from: 'cn', to: 'twp' })
};

new Vue({
    el: '.tool-container',
    data: {
        set: {
            input: '',
            output: ''
        }
    },
    methods: {
        convert(type) {
            if (!this.set.input) {
                showToast('请输入需要转换的文本');
                return;
            }
            
            try {
                const converter = converters[type];
                if (converter) {
                    this.set.output = converter(this.set.input);
                } else {
                    throw new Error('不支持的转换类型');
                }
            } catch (error) {
                console.error('转换失败：', error);
                this.set.output = '转换失败，请稍后重试';
                showToast('转换失败：' + error.message);
            }
        },
        reset() {
            this.set.input = '';
            this.set.output = '';
            showToast('内容已清空');
        },
        copyOutput() {
            const output = document.getElementById('output');
            output.select();
            document.execCommand('copy');
            showToast('已复制转换结果');
        },
        showToast(message) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.textContent = message;
            document.body.appendChild(toast);

            setTimeout(() => {
                toast.remove();
            }, 2000);
        }
    }
}); 