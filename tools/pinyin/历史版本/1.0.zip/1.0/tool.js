// 保留原有的功能函数
function pinyin(text, options = {}) {
    if (typeof pinyin_dict_all === 'undefined') {
        console.error('拼音字典未加载！');
        return text;
    }
    
    const result = text.split('').map(char => {
        // 从字典中获取拼音字符串
        let pinyinStr = pinyin_dict_all[char];

        // 如果找不到拼音，返回原字符
        if (!pinyinStr) {
            return char;
        }

        // 获取第一个拼音（多音字默认取第一个读音）
        let py = pinyinStr.split(',')[0];
        if (options.style === 'STYLE_FIRST_LETTER') {
            // 首字母模式
            py = py.charAt(0);
        } else if (options.style === 'STYLE_NORMAL') {
            // 无声调模式
            py = py
            .replace(/[āáǎàa]/g, 'a')
            .replace(/[ēéěèe]/g, 'e')
            .replace(/[īíǐìi]/g, 'i')
            .replace(/[ōóǒòo]/g, 'o')
            .replace(/[ūúǔùu]/g, 'u')
            .replace(/[ǖǘǚǜüv]/g, 'v');
        }
        // STYLE_TONE 模式下保持原样，显示声调
        return py;
    });
    return result.join(' ');
}

function convertToPinyin() {
    const text = document.getElementById('inputText').value.trim();
    const showTone = document.getElementById('toneOption').checked;
    const firstLetter = document.getElementById('firstLetterOption').checked;
    const upperCase = document.getElementById('upperCaseOption').checked;
    
    if (!text) {
        showToast('请输入需要转换的汉字！');
        return;
    }

    const options = {
        style: firstLetter ? 'STYLE_FIRST_LETTER' : showTone ? 'STYLE_TONE' : 'STYLE_NORMAL'
    };

    let result = pinyin(text, options);
    if (upperCase) {
        result = result.toUpperCase();
    }
    document.getElementById('result').value = result;
}

function copyResult() {
    const result = document.getElementById('result');
    result.select();
    try {
        document.execCommand('copy');
        showToast('复制成功！');
    } catch (err) {
        console.error('复制错误:', err);
        showToast('复制失败，请手动复制');
    }
}

function resetForm() {
    document.getElementById('inputText').value = '';
    document.getElementById('result').value = '';
    document.getElementById('toneOption').checked = true;
    document.getElementById('firstLetterOption').checked = false;
    document.getElementById('upperCaseOption').checked = false;
} 