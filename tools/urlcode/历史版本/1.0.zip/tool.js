// 转换为16进制
function convertToHex() {
    const source = document.getElementById('source').value.trim();
    if (!source) {
        showToast('请输入URL地址！');
        return;
    }

    try {
        // 处理URL前缀
        let prefix = '';
        let urlToConvert = source;
        
        if (source.startsWith('http://')) {
            prefix = 'http://';
            urlToConvert = source.substring(7);
        } else if (source.startsWith('https://')) {
            prefix = 'https://';
            urlToConvert = source.substring(8);
        }

        // 将URL转换为16进制
        const hexResult = Array.from(urlToConvert)
            .map(char => {
                return '%' + char.charCodeAt(0).toString(16).toUpperCase();
            })
            .join('');

        document.getElementById('result').value = prefix + hexResult;
    } catch (e) {
        console.error('转换错误:', e);
        showToast('转换失败：' + e.message);
    }
}

// 从16进制转换回来
function convertFromHex() {
    const source = document.getElementById('source').value.trim();
    if (!source) {
        showToast('请输入16进制编码！');
        return;
    }

    try {
        // 处理URL前缀
        let prefix = '';
        let hexToDecode = source;
        
        if (source.startsWith('http://')) {
            prefix = 'http://';
            hexToDecode = source.substring(7);
        } else if (source.startsWith('https://')) {
            prefix = 'https://';
            hexToDecode = source.substring(8);
        }

        // 解码16进制
        const decoded = hexToDecode.replace(/%([0-9A-Fa-f]{2})/g, (match, p1) => {
            return String.fromCharCode(parseInt(p1, 16));
        });

        document.getElementById('result').value = prefix + decoded;
    } catch (e) {
        console.error('解码错误:', e);
        showToast('解码失败：' + e.message);
    }
}

// 复制结果
function copyResult() {
    const result = document.getElementById('result');
    result.select();
    try {
        document.execCommand('copy');
        showToast('复制成功！');
    } catch (err) {
        console.error('复制错误:', err);
        showToast('复制失败，请手动复制');
    }
} 